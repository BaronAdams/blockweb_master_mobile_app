import Logo from '@/assets/blockweb_master_icon.svg'
import { useState } from 'react'
import './App.css'

function App() {
  const [show, setShow] = useState(false)
  const toggle = () => setShow(!show)

  return (
    <div className="popup-container">
      {show && (
        <div className={`popup-content ${show ? 'opacity-100' : 'opacity-0'}`}>
          <h1>HELLO BLOCKWEB MASTER</h1>
        </div>
      )}
      <button className="toggle-button" onClick={toggle}>
        <img src={Logo} alt="Blockweb Master logo" className="button-icon" />
      </button>
    </div>
  )
}

export default App
